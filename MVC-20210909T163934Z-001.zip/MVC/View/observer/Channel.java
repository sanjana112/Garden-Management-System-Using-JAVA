package bll.observer;

public enum Channel {
    LOGIN, DATA_CHANGE, PLANT_AT, CLOSE, STANDING
}
