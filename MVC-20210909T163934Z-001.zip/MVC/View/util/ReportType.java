package bll.util;

public enum ReportType {
    PDF, TXT
}
