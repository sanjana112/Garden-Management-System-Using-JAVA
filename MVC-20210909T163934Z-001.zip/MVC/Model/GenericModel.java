package model;

public interface GenericModel {
    Long getId();

    void setId(Long id);

}
